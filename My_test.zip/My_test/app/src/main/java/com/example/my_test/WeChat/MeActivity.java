package com.example.my_test.WeChat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.my_test.R;

public class MeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);
    }
}