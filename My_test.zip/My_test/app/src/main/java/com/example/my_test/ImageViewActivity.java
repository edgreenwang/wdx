package com.example.my_test;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ImageViewActivity extends AppCompatActivity {
    private ImageView mIv4;
    private Button loading;
    //    private String url = "https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png";
    private String url = "https://pic.jjawj.cn/iuuqt%3B00jnh%3A%2Fepvcbojp%2Fdpn0wjfx0qipup0m0qvcmjd0q36%3A4791697%2Fkqh.jpg";

    private Handler handle = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    System.out.println("111");
                    Bitmap bmp = (Bitmap) msg.obj;
                    mIv4.setImageBitmap(bmp);
                    break;
            }
        }

        ;
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);

        mIv4 = findViewById(R.id.iv_4);
        loading = findViewById(R.id.loading);
        loading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 显示对话框
                final AlertDialog alert = new AlertDialog.Builder(ImageViewActivity.this).create();
                alert.setTitle("提示信息");
                alert.setMessage("正在加载中，请稍后......");
                alert.show();

//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        alert.dismiss();
//                    }
//                }, 2000);

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Bitmap bmp = getURLimage(url);
                        Message msg = new Message();
                        msg.what = 0;
                        msg.obj = bmp;
                        System.out.println("000");
                        handle.sendMessage(msg);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                alert.dismiss();
                            }
                        });
                    }
                }).start();
            }
        });

//        Glide.with(this).load("https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png").into(mIv4);
    }

    public Bitmap getURLimage(String url) {
        Bitmap bmp = null;
        try {
            URL myurl = new URL(url);
            // 获得连接
            HttpURLConnection conn = (HttpURLConnection) myurl.openConnection();
            conn.setConnectTimeout(6000);//设置超时
            conn.setDoInput(true);
            conn.setUseCaches(false);//不缓存
            conn.connect();
            InputStream is = conn.getInputStream();//获得图片的数据流
            bmp = BitmapFactory.decodeStream(is);
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bmp;
    }
}
