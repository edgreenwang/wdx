package com.example.my_test.WeChat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.my_test.R;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private List<Msg> msgList = new ArrayList<>();
    private EditText inputText;
    private Button send;
    private MsgAdapter adapter;
    private RecyclerView msgRecyclerView;
    private ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        imageButton = findViewById(R.id.ib_return);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChatActivity.this, WeChatActivity.class);
                startActivity(intent);
            }
        });
        initMsgs();  // 初始化消息数据
        inputText = findViewById(R.id.input_text);
        send = findViewById(R.id.send);
        msgRecyclerView = findViewById(R.id.msg_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        msgRecyclerView.setLayoutManager(layoutManager);
        adapter = new MsgAdapter(msgList);
        msgRecyclerView.setAdapter(adapter);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = inputText.getText().toString();
                if (!"".equals(content)) {
                    Msg.msg = new Msg(content, Msg.TYPE_SEND);
                    msgList.add(Msg.msg);
                    adapter.notifyItemInserted(msgList.size() - 1);  //当有新消息时，刷新RecyclerView中的显示
                    msgRecyclerView.scrollToPosition(msgList.size() - 1); //将RecyclerView定位到最后一行
                    inputText.setText("");  // 情况输入框中的内容
                }
            }
        });
    }

    private void initMsgs() {
        Msg msg1 = new Msg("I'll go.", Msg.TYPE_RECELVED);
        msgList.add(msg1);
        Msg msg2 = new Msg("I'll stay.", Msg.TYPE_SEND);
        msgList.add(msg2);
        Msg msg3 = new Msg(" and we'll be OK.", Msg.TYPE_RECELVED);
        msgList.add(msg3);
    }


    public static class Msg {

        public static final int TYPE_RECELVED = 0;
        public static final int TYPE_SEND = 1;
        public static Msg msg;
        private String content;
        private int type;

        public Msg(String content, int type) {
            this.content = content;
            this.type = type;
        }

        public String getContent() {
            return content;
        }

        public int getType() {
            return type;
        }
    }

    public static class MsgAdapter extends RecyclerView.Adapter<MsgAdapter.ViewHolder> {

        private List<ChatActivity.Msg> mMsgList;

        static class ViewHolder extends RecyclerView.ViewHolder {
            LinearLayout leftLayout;
            LinearLayout rightLayout;
            TextView leftMsg;
            TextView rightMsg;
            ImageView fr;
            ImageView me;

            public ViewHolder(View view) {
                super(view);
                leftLayout = (LinearLayout) view.findViewById(R.id.left_layout);
                rightLayout = (LinearLayout) view.findViewById(R.id.right_layout);
                leftMsg = (TextView) view.findViewById(R.id.left_msg);
                rightMsg = (TextView) view.findViewById(R.id.right_msg);
                fr = (ImageView) view.findViewById(R.id.fr);
                me = (ImageView) view.findViewById(R.id.me);
            }
        }
        public MsgAdapter(List<ChatActivity.Msg> msgList) {
            mMsgList = msgList;
        }
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.msg_item, parent, false);
            return new ViewHolder(view);
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            Msg msg = mMsgList.get(position);
            if (msg.getType() == ChatActivity.Msg.TYPE_RECELVED) {

                //如果是收到的消息，则显示左边的消息布局，将右边的消息布局隐藏
                holder.leftLayout.setVisibility(View.VISIBLE);
                holder.rightLayout.setVisibility(View.GONE);
                holder.leftMsg.setText(msg.getContent());
                holder.me.setVisibility(View.GONE);
            } else if (msg.getType() == Msg.TYPE_SEND) {
                //如果是发出的消息，则显示右边的消息布局，将左边的消息布局隐藏
                holder.rightLayout.setVisibility(View.VISIBLE);
                holder.leftLayout.setVisibility(View.GONE);
                holder.rightMsg.setText(msg.getContent());
                holder.fr.setVisibility(View.GONE);
            }
        }
        @Override
        public int getItemCount() {
            return mMsgList.size();
        }
    }
}

