package com.example.my_test.WeChat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.my_test.R;
import com.example.my_test.listview.ListViewActivity;
import com.example.my_test.listview.MyListAdapter;

import java.util.ArrayList;
import java.util.List;

public class WeChatActivity extends AppCompatActivity {

    private ListView mLv;
    private String[] data = {"Apple", "Banana", "orange"};
    private List<Fruit> fruitList = new ArrayList<>();
    private ImageButton mBtnme;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_we_chat);

//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
//                WeChatActivity.this,android.R.layout.simple_list_item_1,data);

        initFruits();   //初始化联系人列表数据
        FruitAdapter adapter = new FruitAdapter(WeChatActivity.this, R.layout.wechat_item, fruitList);
        mLv = findViewById(R.id.lv);
        mLv.setAdapter(adapter);

        //ListView  item 监听器，点击跳转到聊天窗口界面
        mLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Fruit fruit = fruitList.get(position);
                Intent intent = new Intent(WeChatActivity.this, ChatActivity.class);
                startActivity(intent);
            }
        });
        //me 监听器，跳转到个人信息界面
        mBtnme = findViewById(R.id.tab_me_img);
        mBtnme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WeChatActivity.this, MeActivity.class);
                startActivity(intent);
            }
        });
    }

    private void initFruits() {
        for (int i = 0; i < 2; i++) {
            Fruit apple = new Fruit("Apple", R.drawable.apple_pic);
            fruitList.add(apple);
            Fruit banana = new Fruit("Banana", R.drawable.banana_pic);
            fruitList.add(banana);
            Fruit orange = new Fruit("Orange", R.drawable.orange_pic);
            fruitList.add(orange);
        }
    }

    public class Fruit {
        private String name;
        private int imageId;

        public Fruit(String name, int imageId) {
            this.name = name;
            this.imageId = imageId;
        }

        public String getName() {
            return name;
        }

        public int getImageId() {
            return imageId;
        }
    }


    public class FruitAdapter extends ArrayAdapter<Fruit> {

        private int resourceId;

        public FruitAdapter(Context context, int textViewResourceId, List<Fruit> objects) {
            super(context, textViewResourceId, objects);
            resourceId = textViewResourceId;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Fruit fruit = getItem(position);//获取当前项的Fruit联系人实例
            View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
            ImageView fruitImage = (ImageView) view.findViewById(R.id.fruit_image);
            TextView fruitName = (TextView) view.findViewById(R.id.fruit_name);
            fruitImage.setImageResource(fruit.getImageId());
            fruitName.setText(fruit.getName());
            return view;
        }
    }
}