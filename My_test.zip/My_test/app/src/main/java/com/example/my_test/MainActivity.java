package com.example.my_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.my_test.Intent.FirstActivity;
import com.example.my_test.LifeCycle.LifeCycleActivity;
import com.example.my_test.WeChat.WeChatActivity;
import com.example.my_test.listview.ListViewActivity;


public class MainActivity extends AppCompatActivity {

    private Button mBtnTextView;
    private Button mBtnButton;
    private Button mBtnEditText;
    private Button mBtnRadioButton;
    private Button mBtnCheckBox;
    private Button mBtnImageView;
    private Button mBtnListView;
    private Button mBtnLifeCycle;
    private Button mBtnIntent;
    private Button mBtnWeChat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBtnTextView = findViewById(R.id.btn_TextView);
//      mBtnTextView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this,TextViewActivity.class);
//                startActivity(intent);
//
//            }
//        });
        mBtnButton = findViewById(R.id.btn_Button);
//      mBtnButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this,ButtonActivity.class);
//                startActivity(intent);
//            }
//        });
        mBtnEditText = findViewById(R.id.btn_EditText);
//      mBtnEditText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this,EditTextActivity.class);
//                startActivity(intent);
//            }
//        });
        mBtnRadioButton = findViewById(R.id.btn_RadioButton);
        mBtnCheckBox = findViewById(R.id.btn_CheckBox);
        mBtnImageView = findViewById(R.id.btn_ImageView);
        mBtnListView = findViewById(R.id.btn_ListView);
        mBtnLifeCycle = findViewById(R.id.btn_LifeCycle);
        mBtnIntent = findViewById(R.id.btn_Intent);
        mBtnWeChat = findViewById(R.id.btn_WeChat);

         setListeners();
    }
    private void setListeners(){
        OnClick onClick=new OnClick();
        mBtnTextView.setOnClickListener(onClick);
        mBtnButton.setOnClickListener(onClick);
        mBtnEditText.setOnClickListener(onClick);
        mBtnRadioButton.setOnClickListener(onClick);
        mBtnCheckBox.setOnClickListener(onClick);
        mBtnImageView.setOnClickListener(onClick);
        mBtnListView.setOnClickListener(onClick);
        mBtnLifeCycle.setOnClickListener(onClick);
        mBtnIntent.setOnClickListener(onClick);
        mBtnWeChat.setOnClickListener(onClick);

    }
    private class OnClick implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent=null;
            switch (v.getId()){
                case R.id.btn_TextView:
                    //跳转到TextView演示界面
                    intent = new Intent(MainActivity.this,TextViewActivity.class);
                    break;
                case R.id.btn_Button:
                    //跳转到Button演示界面
                    intent = new Intent(MainActivity.this,ButtonActivity.class);
                    break;
                case R.id.btn_EditText:
                    //跳转到EditText演示界面
                    intent = new Intent(MainActivity.this, EditTextActivity.class);
                    break;
                case R.id.btn_RadioButton:
                    //跳转到RadioButton演示界面
                    intent = new Intent(MainActivity.this,RadioButtonActivity.class);
                    break;
                case R.id.btn_CheckBox:
                    //跳转到CheckBox演示页面
                    intent = new Intent(MainActivity.this,CheckBoxActivity.class);
                    break;
                case R.id.btn_ImageView:
                    //跳转到ImageView演示界面
                    intent = new Intent(MainActivity.this,ImageViewActivity.class);
                    break;
                case R.id.btn_ListView:
                    //跳转到ListView演示界面
                    intent = new Intent(MainActivity.this, ListViewActivity.class);
                    break;
                case R.id.btn_LifeCycle:
                    //跳转到LifeCycle演示界面
                    intent = new Intent(MainActivity.this, LifeCycleActivity.class);
                    break;
                case R.id.btn_Intent:
                    //跳转到FirstActivity演示界面
                    intent = new Intent(MainActivity.this, FirstActivity.class);
                    break;
                case R.id.btn_WeChat:
                    //跳转到WeChatActivity演示界面
                    intent = new Intent(MainActivity.this, WeChatActivity.class);
                    break;
            }
            startActivity(intent);
        }
    }
}