package com.example.my_test.Intent;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.my_test.R;

public class FirstActivity extends AppCompatActivity {
    private Button mBtnJump, mBtnMsg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        mBtnMsg = findViewById(R.id.msg);
        mBtnMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri uri = Uri.parse("smsto:13037226761");
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", "你笑起来真像好天气");
                startActivity(intent);

            }
        });


        mBtnJump = findViewById(R.id.jump);
        mBtnJump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //显示跳转1
                Intent intent = new Intent(FirstActivity.this, SecondActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("data", "我是传递的信息");
                intent.putExtras(bundle);
//                startActivity(intent);
                startActivityForResult(intent, 0);

                //显示跳转2
//                Intent intent = new Intent();
//                intent.setClass(FirstActivity.this,SecondActivity.class);
//                startActivity(intent);

                //显示跳转3
//                Intent intent = new Intent();
//                intent.setClassName(FirstActivity.this,"com.example.my_test.Intent.SecondActivity");
//                startActivity(intent);

                //显示跳转4
//                Intent intent = new Intent();
//                intent.setComponent(new ComponentName(FirstActivity.this,"com.example.my_test.Intent.SecondActivity"));
//                startActivity(intent);


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(FirstActivity.this, data.getExtras().getString("data_return"), Toast.LENGTH_LONG).show();
    }
}