package com.example.cameraalbumtest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private ImageView img_show_photo_yuantu,img_show_photo_suolve;
//    private ImageView img_show_photo_select;
    private TextView tv_path;
    String photoPath;
    Uri photoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img_show_photo_yuantu = findViewById(R.id.img_show_photo_yuantu);
        img_show_photo_suolve =  findViewById(R.id.img_show_photo_suolve);
//        img_show_photo_select =  findViewById(R.id.img_show_photo_select);
        tv_path =  findViewById(R.id.tv_path);

    }
    /**
     * 按钮事件
     * @param v
     */
    public void startTakePhoto(View v){
        if (v == findViewById(R.id.btn_start_photo_yuantu)){
            //原图
            Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            File photoFile= createImgFile1();
            photoUri = Uri.fromFile(photoFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
            startActivityForResult(intent,100);
        }
        else if (v == findViewById(R.id.btn_start_photo_suolve)){
            //缩率图
            Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,101);

        }
//        else if (v == findViewById(R.id.btn_start_photo_select)){
//            //选择图片
//            Intent intent = new Intent();
//            intent.setAction(Intent.ACTION_PICK);
//            intent.setType("image/*");
//            startActivityForResult(intent,102);
//        }
    }

    /**
     * activity 返回数据
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            if (requestCode == 100 ) {
                //原图
                Bitmap bitmap  = BitmapFactory.decodeFile(photoPath);
                img_show_photo_yuantu.setImageBitmap(bitmap);
            }
            if (requestCode == 101) {
                //缩略图
                Bundle bundle = data.getExtras();
                Bitmap bitmap = (Bitmap) bundle.get("data");
                img_show_photo_suolve.setImageBitmap(bitmap);
            }
//            if (requestCode == 102) {
//                //选择图片
//                Uri uri = data.getData();
//                Cursor cursor = getContentResolver().query(uri,null,null,null,null);
//                if (cursor.moveToNext()){
//                    int index = cursor.getColumnIndex(MediaStore.Images.Media.DATA);
//                    String path = cursor.getString(index);
//                    Bitmap bitmap  = BitmapFactory.decodeFile(path);
//                    img_show_photo_select.setImageBitmap(bitmap);
//                }
//            }
        }
    }

    /**
     * 自定义图片名，获取照片的file
     */
    private File createImgFile1(){
        //确定文件名
        String fileName="img_"+new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())+".png";
        File dir;
        if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
            dir=Environment.getExternalStorageDirectory();
        }else
        {
            dir=getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        }
        File tempFile=new File(dir,fileName);
        try{
            if(tempFile.exists()){
                tempFile.delete();
            }
            tempFile.createNewFile();
        }catch (IOException e){
            e.printStackTrace();
        }
        //获取文件路径
        photoPath=tempFile.getAbsolutePath();
        tv_path.setText(tempFile.exists()+":"+photoPath);
        return tempFile;
    }

}